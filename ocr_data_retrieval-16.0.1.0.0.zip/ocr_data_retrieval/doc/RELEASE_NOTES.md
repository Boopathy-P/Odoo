## Module <ocr_data_retrieval>

#### 10.01.2024
#### Version 16.0.1.0.0
#### ADD
- Initial commit for OCR Data Retrieval
