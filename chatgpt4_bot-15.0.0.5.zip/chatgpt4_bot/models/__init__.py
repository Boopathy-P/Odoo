# -*- coding: utf-8 -*-

from . import res_config_setting
from . import mail_bot
from . import res_users