# -*- coding: utf-8 -*-

from . import create_menu_dashboard