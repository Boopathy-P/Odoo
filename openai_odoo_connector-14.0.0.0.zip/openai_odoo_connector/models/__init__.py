# -*- coding: utf-8 -*-

from . import res_users
from . import mail_thread
from . import mail_ai_bot
from . import res_config_settings
from . import openai_mixin
from . import openai_result_mixin
from . import openai_completion
from . import openai_completion_result