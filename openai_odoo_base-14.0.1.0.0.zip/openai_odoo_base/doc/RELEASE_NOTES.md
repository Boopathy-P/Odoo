## Module <openai_odoo_base>

#### 31.03.2023
#### Version 14.0.1.0.0
#### ADD
- Initial commit for OpenAI Odoo Base

